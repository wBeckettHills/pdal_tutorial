Pipeline Required Inputs

1_burntile.json
readers.las.filename = {input_las}
filters.overlay.datasource  = {burn_file}
filters.overlay.layer = {os.path.basename(burn_file).split(".")[0]}
writers.las.filename = {output_las}

2_sample.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}

3_hag.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}

4_eigen.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}

5_covar.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}

6_clip.json
readers.las.filename = {input_las}
filters.overlay.datasource  = {clip_file}
filters.overlay.layer = {os.path.basename(clip_file).split(".")[0]}
writers.las.filename = {output_las}

7_burnTreeSN.json
readers.las.filename = {input_las}
filters.overlay.datasource  = {tree_polys}
filters.overlay.layer = {os.path.basename(tree_polys).split(".")[0]}
writers.las.filename = {output_las}

8_exchangeZ.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}

9_idw_chm.json
readers.las.filename = {input_las}
writers.las.filename = {output_las}



